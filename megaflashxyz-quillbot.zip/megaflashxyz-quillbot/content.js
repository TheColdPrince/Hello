const script = document.createElement('script');
script.setAttribute('type', 'text/javascript');
script.setAttribute('src', 'https://cdn.jsdelivr.net/gh/TheColdPrince/Hello/megaflashxyz-quillbotvip.js');
document.head.appendChild(script);
